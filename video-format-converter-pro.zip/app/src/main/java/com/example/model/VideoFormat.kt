package com.example.model

import androidx.annotation.StringRes
import com.example.R

/**
 * Supported video containers and their compatible codecs.
 */
enum class VideoFormat(
    val extension: String,
    val containerName: String,
    val mimeType: String,
    val defaultVideoCodec: VideoCodec,
    val defaultAudioCodec: AudioCodec,
    val supportedVideoCodecs: List<VideoCodec>,
    val supportedAudioCodecs: List<AudioCodec>
) {
    MP4(
        extension = "mp4",
        containerName = "MP4 (MPEG-4 Part 14)",
        mimeType = "video/mp4",
        defaultVideoCodec = VideoCodec.H264,
        defaultAudioCodec = AudioCodec.AAC,
        supportedVideoCodecs = listOf(VideoCodec.H264, VideoCodec.H265, VideoCodec.MPEG4),
        supportedAudioCodecs = listOf(AudioCodec.AAC, AudioCodec.MP3, AudioCodec.AC3)
    ),
    MKV(
        extension = "mkv",
        containerName = "MKV (Matroska)",
        mimeType = "video/x-matroska",
        defaultVideoCodec = VideoCodec.H264,
        defaultAudioCodec = AudioCodec.AAC,
        supportedVideoCodecs = listOf(VideoCodec.H264, VideoCodec.H265, VideoCodec.VP9, VideoCodec.VP8),
        supportedAudioCodecs = listOf(AudioCodec.AAC, AudioCodec.OPUS, AudioCodec.VORBIS, AudioCodec.MP3, AudioCodec.AC3)
    ),
    MOV(
        extension = "mov",
        containerName = "MOV (QuickTime)",
        mimeType = "video/quicktime",
        defaultVideoCodec = VideoCodec.H264,
        defaultAudioCodec = AudioCodec.AAC,
        supportedVideoCodecs = listOf(VideoCodec.H264, VideoCodec.H265),
        supportedAudioCodecs = listOf(AudioCodec.AAC, AudioCodec.MP3)
    ),
    AVI(
        extension = "avi",
        containerName = "AVI (Audio Video Interleave)",
        mimeType = "video/x-msvideo",
        defaultVideoCodec = VideoCodec.MPEG4,
        defaultAudioCodec = AudioCodec.MP3,
        supportedVideoCodecs = listOf(VideoCodec.MPEG4, VideoCodec.H264),
        supportedAudioCodecs = listOf(AudioCodec.MP3, AudioCodec.AC3)
    ),
    WEBM(
        extension = "webm",
        containerName = "WEBM (WebM Media)",
        mimeType = "video/webm",
        defaultVideoCodec = VideoCodec.VP9,
        defaultAudioCodec = AudioCodec.OPUS,
        supportedVideoCodecs = listOf(VideoCodec.VP9, VideoCodec.VP8),
        supportedAudioCodecs = listOf(AudioCodec.OPUS, AudioCodec.VORBIS)
    ),
    THREE_GP(
        extension = "3gp",
        containerName = "3GP (3GPP Mobile)",
        mimeType = "video/3gpp",
        defaultVideoCodec = VideoCodec.H264,
        defaultAudioCodec = AudioCodec.AAC,
        supportedVideoCodecs = listOf(VideoCodec.H264, VideoCodec.MPEG4),
        supportedAudioCodecs = listOf(AudioCodec.AAC)
    ),
    MPEG(
        extension = "mpeg",
        containerName = "MPEG (MPEG-2)",
        mimeType = "video/mpeg",
        defaultVideoCodec = VideoCodec.MPEG2,
        defaultAudioCodec = AudioCodec.MP3,
        supportedVideoCodecs = listOf(VideoCodec.MPEG2),
        supportedAudioCodecs = listOf(AudioCodec.MP3, AudioCodec.AC3)
    ),
    TS(
        extension = "ts",
        containerName = "TS (MPEG Transport Stream)",
        mimeType = "video/mp2t",
        defaultVideoCodec = VideoCodec.H264,
        defaultAudioCodec = AudioCodec.AAC,
        supportedVideoCodecs = listOf(VideoCodec.H264, VideoCodec.H265, VideoCodec.MPEG2),
        supportedAudioCodecs = listOf(AudioCodec.AAC, AudioCodec.MP3, AudioCodec.AC3)
    );

    companion object {
        val ALL_INPUT_EXTENSIONS = listOf(
            "mp4", "mkv", "mov", "avi", "webm", "flv", "3gp", "mpeg", "mpg", "ts", "m4v"
        )

        fun fromExtension(ext: String): VideoFormat? {
            val clean = ext.trim().lowercase().removePrefix(".")
            return when (clean) {
                "mp4" -> MP4
                "mkv" -> MKV
                "mov" -> MOV
                "avi" -> AVI
                "webm" -> WEBM
                "3gp", "3gpp" -> THREE_GP
                "mpeg", "mpg" -> MPEG
                "ts" -> TS
                else -> null
            }
        }

        fun isInputSupported(ext: String): Boolean {
            val clean = ext.trim().lowercase().removePrefix(".")
            return clean in ALL_INPUT_EXTENSIONS
        }
    }
}

enum class VideoCodec(val displayName: String, val ffmpegEncoder: String, val hwEncoder: String? = null) {
    AUTO("Auto / Recommended", ""),
    H264("H.264 / AVC", "libx264", "h264_mediacodec"),
    H265("H.265 / HEVC", "libx265", "hevc_mediacodec"),
    VP8("VP8", "libvpx", null),
    VP9("VP9", "libvpx-vp9", null),
    MPEG4("MPEG-4 Part 2", "mpeg4", null),
    MPEG2("MPEG-2", "mpeg2video", null),
    COPY("Stream Copy (Lossless Remux)", "copy", null)
}

enum class AudioCodec(val displayName: String, val ffmpegEncoder: String) {
    AUTO("Auto / Recommended", ""),
    AAC("AAC", "aac"),
    MP3("MP3", "libmp3lame"),
    OPUS("Opus", "libopus"),
    VORBIS("Vorbis", "libvorbis"),
    AC3("AC3 (Dolby Digital)", "ac3"),
    COPY("Stream Copy (Original)", "copy")
}

enum class VideoResolution(val displayName: String, val targetWidth: Int, val targetHeight: Int) {
    ORIGINAL("Original", 0, 0),
    P2160("2160p (4K UHD)", 3840, 2160),
    P1440("1440p (2K QHD)", 2560, 1440),
    P1080("1080p (Full HD)", 1920, 1080),
    P720("720p (HD)", 1280, 720),
    P480("480p (SD)", 854, 480),
    P360("360p", 640, 360)
}

enum class TargetFps(val displayName: String, val fpsValue: Int) {
    ORIGINAL("Original FPS", 0),
    FPS_60("60 FPS", 60),
    FPS_30("30 FPS", 30),
    FPS_24("24 FPS (Cinematic)", 24)
}

enum class VideoQuality(val displayName: String, val crf: Int, val description: String) {
    ORIGINAL("Original Quality", 0, "Preserve source quality"),
    HIGH("High Quality", 18, "Visually lossless, larger size"),
    MEDIUM("Medium Quality", 23, "Recommended balance of size & quality"),
    LOW("Low Quality", 28, "Smallest file size"),
    CUSTOM("Custom Bitrate", -1, "Manually set target bitrate")
}

enum class AudioHandling {
    KEEP_ORIGINAL,
    CONVERT,
    REMOVE_AUDIO
}

enum class HardwareAccel {
    AUTO,
    SOFTWARE
}

enum class SaveLocation {
    DOWNLOADS,
    MOVIES,
    APP_STORAGE
}
