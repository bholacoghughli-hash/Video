package com.example.model

import android.net.Uri

data class VideoMetadata(
    val uri: Uri,
    val fileName: String,
    val fileSizeBytes: Long = 0L,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val fps: Double = 0.0,
    val videoCodec: String = "Unknown",
    val audioCodec: String = "Unknown",
    val formatName: String = "Unknown",
    val bitrateKbps: Long = 0L,
    val localFilePath: String? = null
) {
    val resolutionFormatted: String
        get() = if (width > 0 && height > 0) "${width}x${height}" else "Unknown"

    val durationFormatted: String
        get() {
            if (durationMs <= 0) return "00:00"
            val totalSeconds = durationMs / 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }

    val fileSizeFormatted: String
        get() {
            if (fileSizeBytes <= 0) return "0 MB"
            val kb = fileSizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.2f MB", mb)
                else -> String.format("%.1f KB", kb)
            }
        }

    val fpsFormatted: String
        get() = if (fps > 0) String.format("%.1f FPS", fps) else "Unknown"
}

data class ConversionConfig(
    val outputFormat: VideoFormat = VideoFormat.MP4,
    val videoCodec: VideoCodec = VideoCodec.AUTO,
    val audioCodec: AudioCodec = AudioCodec.AUTO,
    val resolution: VideoResolution = VideoResolution.ORIGINAL,
    val fps: TargetFps = TargetFps.ORIGINAL,
    val quality: VideoQuality = VideoQuality.MEDIUM,
    val customBitrateKbps: Int = 2500,
    val audioHandling: AudioHandling = AudioHandling.KEEP_ORIGINAL,
    val hardwareAccel: HardwareAccel = HardwareAccel.AUTO,
    val outputFileName: String = "",
    val saveLocation: SaveLocation = SaveLocation.DOWNLOADS
)

data class ConversionProgress(
    val percentage: Int = 0,
    val processedMs: Long = 0L,
    val totalMs: Long = 0L,
    val remainingTimeMs: Long = 0L,
    val speedMultiplier: Double = 1.0,
    val currentStage: String = "Preparing",
    val bitrateKbps: Double = 0.0,
    val currentSizeFormatted: String = ""
) {
    val remainingTimeFormatted: String
        get() {
            if (remainingTimeMs <= 0) return "--:--"
            val totalSec = remainingTimeMs / 1000
            val mins = totalSec / 60
            val secs = totalSec % 60
            return String.format("%02d:%02d", mins, secs)
        }

    val processedTimeFormatted: String
        get() {
            val totalSec = processedMs / 1000
            val mins = totalSec / 60
            val secs = totalSec % 60
            return String.format("%02d:%02d", mins, secs)
        }

    val speedFormatted: String
        get() = if (speedMultiplier > 0.0) String.format("%.2fx", speedMultiplier) else "1.0x"
}

data class ConversionResult(
    val isSuccess: Boolean,
    val outputFilePath: String? = null,
    val outputUri: Uri? = null,
    val outputFileName: String = "",
    val outputSizeBytes: Long = 0L,
    val durationMs: Long = 0L,
    val format: String = "",
    val resolution: String = "",
    val errorMessage: String? = null,
    val technicalDetails: String? = null
)

data class BatchVideoItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val uri: Uri,
    val metadata: VideoMetadata,
    val config: ConversionConfig,
    val status: BatchStatus = BatchStatus.WAITING,
    val progress: Int = 0,
    val result: ConversionResult? = null,
    val errorMessage: String? = null
)

enum class BatchStatus {
    WAITING,
    CONVERTING,
    COMPLETED,
    FAILED,
    CANCELLED
}
