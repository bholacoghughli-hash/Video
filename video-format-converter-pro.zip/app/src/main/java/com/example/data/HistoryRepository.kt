package com.example.data

import kotlinx.coroutines.flow.Flow

class HistoryRepository(private val dao: ConversionHistoryDao) {
    val allHistory: Flow<List<ConversionHistoryEntity>> = dao.getAllHistory()
    val recentHistory: Flow<List<ConversionHistoryEntity>> = dao.getRecentHistory()
    val count: Flow<Int> = dao.getCount()

    suspend fun insert(item: ConversionHistoryEntity): Long = dao.insertHistory(item)

    suspend fun delete(item: ConversionHistoryEntity) = dao.deleteHistory(item)

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun clearAll() = dao.clearAll()
}
