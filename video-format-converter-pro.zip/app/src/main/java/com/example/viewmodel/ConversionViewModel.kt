package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ConversionHistoryEntity
import com.example.data.HistoryRepository
import com.example.engine.EngineConversionEvent
import com.example.engine.MediaMetadataHelper
import com.example.engine.StorageManager
import com.example.engine.VideoConversionEngine
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class UiConversionState {
    object Idle : UiConversionState()
    data class LoadingMetadata(val fileName: String) : UiConversionState()
    data class Ready(val metadata: VideoMetadata) : UiConversionState()
    data class Converting(val progress: ConversionProgress, val metadata: VideoMetadata) : UiConversionState()
    data class Completed(val result: ConversionResult, val metadata: VideoMetadata) : UiConversionState()
    data class Error(val message: String, val technicalDetails: String?, val metadata: VideoMetadata?) : UiConversionState()
}

data class StorageStats(
    val availableBytes: Long = 0L,
    val appUsedBytes: Long = 0L,
    val convertedFilesCount: Int = 0
)

class ConversionViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val database = AppDatabase.getInstance(context)
    private val repository = HistoryRepository(database.conversionHistoryDao())
    private val engine = VideoConversionEngine(context)

    // UI Conversion State
    private val _conversionState = MutableStateFlow<UiConversionState>(UiConversionState.Idle)
    val conversionState: StateFlow<UiConversionState> = _conversionState.asStateFlow()

    // Active Config
    private val _config = MutableStateFlow(ConversionConfig())
    val config: StateFlow<ConversionConfig> = _config.asStateFlow()

    // Active Metadata
    private val _selectedMetadata = MutableStateFlow<VideoMetadata?>(null)
    val selectedMetadata: StateFlow<VideoMetadata?> = _selectedMetadata.asStateFlow()

    // Batch Queue
    private val _batchQueue = MutableStateFlow<List<BatchVideoItem>>(emptyList())
    val batchQueue: StateFlow<List<BatchVideoItem>> = _batchQueue.asStateFlow()

    private val _isBatchProcessing = MutableStateFlow(false)
    val isBatchProcessing: StateFlow<Boolean> = _isBatchProcessing.asStateFlow()

    // History
    val historyList: StateFlow<List<ConversionHistoryEntity>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentHistory: StateFlow<List<ConversionHistoryEntity>> = repository.recentHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Storage stats
    private val _storageStats = MutableStateFlow(StorageStats())
    val storageStats: StateFlow<StorageStats> = _storageStats.asStateFlow()

    // Preferences: Language, Theme, and Developer Contact Visibility
    private val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
    private val _currentLanguage = MutableStateFlow(prefs.getString("pref_language", "en") ?: "en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _currentTheme = MutableStateFlow(prefs.getString("pref_theme", "system") ?: "system")
    val currentTheme: StateFlow<String> = _currentTheme.asStateFlow()

    private val _developerContactVisibility = MutableStateFlow(prefs.getString("pref_dev_contact_visibility", "Public") ?: "Public")
    val developerContactVisibility: StateFlow<String> = _developerContactVisibility.asStateFlow()

    private var conversionJob: Job? = null
    private var batchJob: Job? = null

    init {
        refreshStorageStats()
    }

    fun refreshStorageStats() {
        viewModelScope.launch(Dispatchers.IO) {
            val available = StorageManager.getAvailableStorageBytes(context)
            val used = StorageManager.getConvertedFilesSizeBytes(context)
            val count = StorageManager.getConvertedFilesCount(context)
            _storageStats.value = StorageStats(available, used, count)
        }
    }

    fun onVideoSelected(uri: Uri) {
        viewModelScope.launch {
            val fileName = MediaMetadataHelper.getFileNameFromUri(context, uri)
            _conversionState.value = UiConversionState.LoadingMetadata(fileName)

            val metadata = MediaMetadataHelper.extractMetadata(context, uri)
            _selectedMetadata.value = metadata

            // Suggest smart defaults based on input
            val inputExt = metadata.fileName.substringAfterLast('.', "").lowercase()
            val defaultOutputFormat = if (inputExt == "mp4") VideoFormat.MKV else VideoFormat.MP4
            val baseName = metadata.fileName.substringBeforeLast('.')

            _config.value = _config.value.copy(
                outputFormat = defaultOutputFormat,
                videoCodec = VideoCodec.AUTO,
                audioCodec = AudioCodec.AUTO,
                outputFileName = "${baseName}_converted"
            )

            _conversionState.value = UiConversionState.Ready(metadata)
        }
    }

    fun updateConfig(update: (ConversionConfig) -> ConversionConfig) {
        _config.value = update(_config.value)
    }

    fun startConversion() {
        val metadata = _selectedMetadata.value ?: return
        val currentConfig = _config.value

        conversionJob?.cancel()
        conversionJob = viewModelScope.launch {
            engine.convertVideo(metadata.uri, metadata, currentConfig).collect { event ->
                when (event) {
                    is EngineConversionEvent.Progress -> {
                        _conversionState.value = UiConversionState.Converting(event.progress, metadata)
                    }
                    is EngineConversionEvent.Completed -> {
                        _conversionState.value = UiConversionState.Completed(event.result, metadata)
                        // Save to history
                        repository.insert(
                            ConversionHistoryEntity(
                                originalFileName = metadata.fileName,
                                outputFileName = event.result.outputFileName,
                                inputFormat = metadata.formatName,
                                outputFormat = event.result.format,
                                fileSizeBytes = event.result.outputSizeBytes,
                                durationMs = event.result.durationMs,
                                resolution = event.result.resolution,
                                outputPath = event.result.outputFilePath ?: "",
                                isSuccess = true
                            )
                        )
                        refreshStorageStats()
                    }
                    is EngineConversionEvent.Error -> {
                        _conversionState.value = UiConversionState.Error(event.message, event.technicalDetails, metadata)
                        repository.insert(
                            ConversionHistoryEntity(
                                originalFileName = metadata.fileName,
                                outputFileName = currentConfig.outputFileName,
                                inputFormat = metadata.formatName,
                                outputFormat = currentConfig.outputFormat.extension.uppercase(),
                                fileSizeBytes = 0L,
                                durationMs = 0L,
                                resolution = "",
                                outputPath = "",
                                isSuccess = false
                            )
                        )
                    }
                    is EngineConversionEvent.Cancelled -> {
                        _conversionState.value = UiConversionState.Ready(metadata)
                    }
                }
            }
        }
    }

    fun cancelConversion() {
        engine.cancelActiveConversion()
        conversionJob?.cancel()
        val metadata = _selectedMetadata.value
        if (metadata != null) {
            _conversionState.value = UiConversionState.Ready(metadata)
        } else {
            _conversionState.value = UiConversionState.Idle
        }
    }

    fun resetToReady() {
        val metadata = _selectedMetadata.value
        if (metadata != null) {
            _conversionState.value = UiConversionState.Ready(metadata)
        } else {
            _conversionState.value = UiConversionState.Idle
        }
    }

    fun resetAll() {
        _selectedMetadata.value = null
        _conversionState.value = UiConversionState.Idle
    }

    // --- Batch Conversion ---

    fun addBatchVideos(uris: List<Uri>) {
        viewModelScope.launch {
            val newItems = mutableListOf<BatchVideoItem>()
            for (uri in uris) {
                val metadata = MediaMetadataHelper.extractMetadata(context, uri)
                val inputExt = metadata.fileName.substringAfterLast('.', "").lowercase()
                val targetFormat = if (inputExt == "mp4") VideoFormat.MKV else VideoFormat.MP4
                val baseName = metadata.fileName.substringBeforeLast('.')
                val config = ConversionConfig(
                    outputFormat = targetFormat,
                    outputFileName = "${baseName}_converted"
                )
                newItems.add(BatchVideoItem(uri = uri, metadata = metadata, config = config))
            }
            _batchQueue.value = _batchQueue.value + newItems
        }
    }

    fun removeBatchItem(id: String) {
        _batchQueue.value = _batchQueue.value.filter { it.id != id }
    }

    fun clearCompletedBatch() {
        _batchQueue.value = _batchQueue.value.filter { it.status != BatchStatus.COMPLETED && it.status != BatchStatus.FAILED }
    }

    fun startBatchConversion() {
        if (_isBatchProcessing.value) return
        _isBatchProcessing.value = true

        batchJob = viewModelScope.launch {
            val items = _batchQueue.value.toMutableList()
            for (i in items.indices) {
                val item = items[i]
                if (item.status != BatchStatus.WAITING) continue

                // Update to CONVERTING
                items[i] = item.copy(status = BatchStatus.CONVERTING, progress = 0)
                _batchQueue.value = items.toList()

                val itemEngine = VideoConversionEngine(context)
                itemEngine.convertVideo(item.uri, item.metadata, item.config).collect { event ->
                    when (event) {
                        is EngineConversionEvent.Progress -> {
                            val currentItems = _batchQueue.value.toMutableList()
                            val idx = currentItems.indexOfFirst { it.id == item.id }
                            if (idx != -1) {
                                currentItems[idx] = currentItems[idx].copy(progress = event.progress.percentage)
                                _batchQueue.value = currentItems
                            }
                        }
                        is EngineConversionEvent.Completed -> {
                            val currentItems = _batchQueue.value.toMutableList()
                            val idx = currentItems.indexOfFirst { it.id == item.id }
                            if (idx != -1) {
                                currentItems[idx] = currentItems[idx].copy(
                                    status = BatchStatus.COMPLETED,
                                    progress = 100,
                                    result = event.result
                                )
                                _batchQueue.value = currentItems
                            }
                            repository.insert(
                                ConversionHistoryEntity(
                                    originalFileName = item.metadata.fileName,
                                    outputFileName = event.result.outputFileName,
                                    inputFormat = item.metadata.formatName,
                                    outputFormat = event.result.format,
                                    fileSizeBytes = event.result.outputSizeBytes,
                                    durationMs = event.result.durationMs,
                                    resolution = event.result.resolution,
                                    outputPath = event.result.outputFilePath ?: "",
                                    isSuccess = true
                                )
                            )
                        }
                        is EngineConversionEvent.Error -> {
                            val currentItems = _batchQueue.value.toMutableList()
                            val idx = currentItems.indexOfFirst { it.id == item.id }
                            if (idx != -1) {
                                currentItems[idx] = currentItems[idx].copy(
                                    status = BatchStatus.FAILED,
                                    errorMessage = event.message
                                )
                                _batchQueue.value = currentItems
                            }
                        }
                        is EngineConversionEvent.Cancelled -> {
                            val currentItems = _batchQueue.value.toMutableList()
                            val idx = currentItems.indexOfFirst { it.id == item.id }
                            if (idx != -1) {
                                currentItems[idx] = currentItems[idx].copy(status = BatchStatus.CANCELLED)
                                _batchQueue.value = currentItems
                            }
                        }
                    }
                }
            }
            _isBatchProcessing.value = false
            refreshStorageStats()
        }
    }

    fun cancelBatchProcessing() {
        batchJob?.cancel()
        _isBatchProcessing.value = false
        _batchQueue.value = _batchQueue.value.map {
            if (it.status == BatchStatus.CONVERTING) it.copy(status = BatchStatus.CANCELLED) else it
        }
    }

    // --- History Actions ---

    fun deleteHistoryItem(item: ConversionHistoryEntity) {
        viewModelScope.launch {
            repository.delete(item)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    // --- Settings Actions ---

    fun clearAllConvertedFiles() {
        viewModelScope.launch {
            StorageManager.clearConvertedFiles(context)
            MediaMetadataHelper.clearCacheFiles(context)
            refreshStorageStats()
        }
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
        prefs.edit().putString("pref_language", lang).apply()
    }

    fun setTheme(theme: String) {
        _currentTheme.value = theme
        prefs.edit().putString("pref_theme", theme).apply()
    }

    fun setDeveloperContactVisibility(visibility: String) {
        _developerContactVisibility.value = visibility
        prefs.edit().putString("pref_dev_contact_visibility", visibility).apply()
    }
}
