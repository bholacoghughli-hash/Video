package com.example.engine

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.example.model.VideoFormat
import com.example.model.VideoMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object MediaMetadataHelper {

    private const val TAG = "MediaMetadataHelper"

    /**
     * Extracts full metadata from a video URI using MediaMetadataRetriever and MediaExtractor.
     */
    suspend fun extractMetadata(context: Context, uri: Uri): VideoMetadata = withContext(Dispatchers.IO) {
        val fileName = getFileNameFromUri(context, uri)
        val fileSizeBytes = getFileSizeBytes(context, uri)

        var durationMs = 0L
        var width = 0
        var height = 0
        var fps = 0.0
        var videoCodec = "Unknown"
        var audioCodec = "Unknown"
        var bitrate = 0L

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)

            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 0L

            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            width = widthStr?.toIntOrNull() ?: 0
            height = heightStr?.toIntOrNull() ?: 0

            // Account for rotation
            val rotationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            val rotation = rotationStr?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) {
                val temp = width
                width = height
                height = temp
            }

            val bitrateStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            bitrate = (bitrateStr?.toLongOrNull() ?: 0L) / 1000

            val hasAudioStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            if (hasAudioStr != null && hasAudioStr.equals("yes", ignoreCase = true)) {
                audioCodec = "Audio Track Present"
            }

            val hasVideoStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            if (hasVideoStr != null && hasVideoStr.equals("yes", ignoreCase = true)) {
                videoCodec = "Video Track Present"
            }
        } catch (e: Exception) {
            Log.w(TAG, "MediaMetadataRetriever error: ${e.message}")
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        // Use MediaExtractor to inspect track MIME types for precise codecs and frame rate
        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(context, uri, null)
            val trackCount = extractor.trackCount
            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue

                if (mime.startsWith("video/")) {
                    videoCodec = formatMimeToCodecName(mime)
                    if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = format.getInteger(MediaFormat.KEY_FRAME_RATE).toDouble()
                    }
                    if (width == 0 && format.containsKey(MediaFormat.KEY_WIDTH)) {
                        width = format.getInteger(MediaFormat.KEY_WIDTH)
                    }
                    if (height == 0 && format.containsKey(MediaFormat.KEY_HEIGHT)) {
                        height = format.getInteger(MediaFormat.KEY_HEIGHT)
                    }
                } else if (mime.startsWith("audio/")) {
                    audioCodec = formatMimeToCodecName(mime)
                }
            }
            extractor.release()
        } catch (e: Exception) {
            Log.w(TAG, "MediaExtractor error: ${e.message}")
        }

        // Estimate FPS if not reported by extractor
        if (fps <= 0.0 && durationMs > 0) {
            fps = 30.0 // standard default fallback
        }

        val formatName = fileName.substringAfterLast('.', "").uppercase().ifEmpty { "VIDEO" }

        VideoMetadata(
            uri = uri,
            fileName = fileName,
            fileSizeBytes = fileSizeBytes,
            durationMs = durationMs,
            width = width,
            height = height,
            fps = fps,
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            formatName = formatName,
            bitrateKbps = bitrate
        )
    }

    private fun formatMimeToCodecName(mime: String): String {
        return when (mime) {
            MediaFormat.MIMETYPE_VIDEO_AVC -> "H.264 / AVC"
            MediaFormat.MIMETYPE_VIDEO_HEVC -> "H.265 / HEVC"
            MediaFormat.MIMETYPE_VIDEO_VP8 -> "VP8"
            MediaFormat.MIMETYPE_VIDEO_VP9 -> "VP9"
            MediaFormat.MIMETYPE_VIDEO_MPEG4 -> "MPEG-4"
            MediaFormat.MIMETYPE_VIDEO_H263 -> "H.263"
            MediaFormat.MIMETYPE_AUDIO_AAC -> "AAC"
            MediaFormat.MIMETYPE_AUDIO_MPEG -> "MP3"
            MediaFormat.MIMETYPE_AUDIO_OPUS -> "Opus"
            MediaFormat.MIMETYPE_AUDIO_VORBIS -> "Vorbis"
            MediaFormat.MIMETYPE_AUDIO_AC3 -> "AC3"
            MediaFormat.MIMETYPE_AUDIO_EAC3 -> "E-AC3"
            MediaFormat.MIMETYPE_AUDIO_FLAC -> "FLAC"
            else -> mime.substringAfter('/')
        }
    }

    fun getFileNameFromUri(context: Context, uri: Uri): String {
        var name = "video_${System.currentTimeMillis()}.mp4"
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val retrievedName = it.getString(nameIndex)
                        if (!retrievedName.isNullOrBlank()) {
                            name = retrievedName
                        }
                    }
                }
            }
        } else if (uri.scheme == "file") {
            val path = uri.path
            if (path != null) {
                name = File(path).name
            }
        }
        return name
    }

    fun getFileSizeBytes(context: Context, uri: Uri): Long {
        var size = 0L
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex != -1) {
                        size = it.getLong(sizeIndex)
                    }
                }
            }
        } else if (uri.scheme == "file") {
            val path = uri.path
            if (path != null) {
                size = File(path).length()
            }
        }
        return size
    }

    /**
     * Efficiently streams input content URI into a local temporary cache file for FFmpeg to process.
     * Uses buffer streaming to prevent OutOfMemoryError.
     */
    suspend fun copyUriToCacheFile(context: Context, uri: Uri, targetFileName: String): File = withContext(Dispatchers.IO) {
        val cacheDir = File(context.cacheDir, "converter_inputs")
        if (!cacheDir.exists()) cacheDir.mkdirs()

        // Sanitize file name to avoid path traversal
        val safeName = targetFileName.replace("[/\\\\:*?\"<>|]".toRegex(), "_")
        val destFile = File(cacheDir, "input_${System.currentTimeMillis()}_$safeName")

        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            FileOutputStream(destFile).use { outputStream ->
                val buffer = ByteArray(64 * 1024) // 64 KB streaming buffer
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                }
                outputStream.flush()
            }
        } ?: throw IllegalStateException("Could not open input stream for $uri")

        destFile
    }

    /**
     * Cleans up temporary cache files.
     */
    fun clearCacheFiles(context: Context) {
        try {
            val inputDir = File(context.cacheDir, "converter_inputs")
            if (inputDir.exists()) inputDir.deleteRecursively()

            val outputDir = File(context.cacheDir, "converter_outputs")
            if (outputDir.exists()) outputDir.deleteRecursively()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clear cache files: ${e.message}")
        }
    }
}
