package com.example.engine

import com.example.model.*

object FFmpegCommandGenerator {

    data class GeneratedCommand(
        val arguments: List<String>,
        val isRemuxing: Boolean,
        val explanation: String
    ) {
        val asCommandLineString: String
            get() = arguments.joinToString(" ") { arg ->
                if (arg.contains(" ") || arg.contains("\"") || arg.contains("'")) {
                    "\"" + arg.replace("\"", "\\\"") + "\""
                } else {
                    arg
                }
            }
    }

    /**
     * Checks if lossless stream copying (remuxing) is possible between the input video metadata
     * and requested output configuration.
     */
    fun canRemux(
        inputMetadata: VideoMetadata,
        config: ConversionConfig
    ): Boolean {
        // If user changed resolution, fps, or quality, or asked to convert/remove audio, we must transcode.
        if (config.resolution != VideoResolution.ORIGINAL) return false
        if (config.fps != TargetFps.ORIGINAL) return false
        if (config.quality == VideoQuality.CUSTOM) return false
        if (config.audioHandling == AudioHandling.REMOVE_AUDIO) return false
        if (config.videoCodec != VideoCodec.AUTO && config.videoCodec != VideoCodec.COPY) return false
        if (config.audioCodec != AudioCodec.AUTO && config.audioCodec != AudioCodec.COPY) return false

        val inputExt = inputMetadata.fileName.substringAfterLast('.', "").lowercase()
        val targetFormat = config.outputFormat

        // Codec compatibility with target container
        val vCodec = inputMetadata.videoCodec.lowercase()
        val aCodec = inputMetadata.audioCodec.lowercase()

        val isVideoCompatible = when (targetFormat) {
            VideoFormat.MP4 -> vCodec.contains("h264") || vCodec.contains("avc") || vCodec.contains("h265") || vCodec.contains("hevc") || vCodec.contains("mpeg4")
            VideoFormat.MKV -> true // Matroska accepts nearly all codecs!
            VideoFormat.MOV -> vCodec.contains("h264") || vCodec.contains("avc") || vCodec.contains("hevc") || vCodec.contains("h265") || vCodec.contains("prores")
            VideoFormat.AVI -> vCodec.contains("mpeg4") || vCodec.contains("xvid") || vCodec.contains("mjpeg")
            VideoFormat.WEBM -> vCodec.contains("vp8") || vCodec.contains("vp9") || vCodec.contains("av1")
            VideoFormat.THREE_GP -> vCodec.contains("h264") || vCodec.contains("h263") || vCodec.contains("mpeg4")
            VideoFormat.MPEG -> vCodec.contains("mpeg1") || vCodec.contains("mpeg2")
            VideoFormat.TS -> vCodec.contains("h264") || vCodec.contains("hevc") || vCodec.contains("mpeg2")
        }

        val isAudioCompatible = when (targetFormat) {
            VideoFormat.MP4 -> aCodec.contains("aac") || aCodec.contains("mp3") || aCodec.contains("ac3") || aCodec.isEmpty() || aCodec == "none"
            VideoFormat.MKV -> true // Matroska accepts Opus, Vorbis, AAC, MP3, AC3, FLAC, etc.
            VideoFormat.MOV -> aCodec.contains("aac") || aCodec.contains("pcm") || aCodec.contains("mp3")
            VideoFormat.AVI -> aCodec.contains("mp3") || aCodec.contains("ac3") || aCodec.contains("pcm")
            VideoFormat.WEBM -> aCodec.contains("opus") || aCodec.contains("vorbis")
            VideoFormat.THREE_GP -> aCodec.contains("aac") || aCodec.contains("amr")
            VideoFormat.MPEG -> aCodec.contains("mp2") || aCodec.contains("mp3")
            VideoFormat.TS -> aCodec.contains("aac") || aCodec.contains("ac3") || aCodec.contains("mp2")
        }

        return isVideoCompatible && isAudioCompatible
    }

    /**
     * Builds safe arguments array for FFmpegKit execution.
     * Guaranteed safe against command injection, spaces, Devanagari/Hindi characters, and emojis.
     */
    fun buildCommand(
        inputFilePath: String,
        outputFilePath: String,
        inputMetadata: VideoMetadata,
        config: ConversionConfig
    ): GeneratedCommand {
        val args = mutableListOf<String>()

        // Overwrite output file without asking
        args.add("-y")

        // Input file
        args.add("-i")
        args.add(inputFilePath)

        val remuxPossible = canRemux(inputMetadata, config)

        if (remuxPossible) {
            // Remuxing
            args.add("-c:v")
            args.add("copy")
            args.add("-c:a")
            args.add("copy")

            if (config.outputFormat == VideoFormat.MP4 || config.outputFormat == VideoFormat.MOV) {
                args.add("-movflags")
                args.add("+faststart")
            }

            args.add(outputFilePath)

            return GeneratedCommand(
                arguments = args,
                isRemuxing = true,
                explanation = "Lossless remuxing: Codecs are fully compatible with ${config.outputFormat.extension.uppercase()} container. No re-encoding needed!"
            )
        }

        // Transcoding required
        val videoFilters = mutableListOf<String>()

        // Resolution filter (scale)
        if (config.resolution != VideoResolution.ORIGINAL) {
            val targetW = config.resolution.targetWidth
            val targetH = config.resolution.targetHeight
            // Never upscale if original is smaller unless user targeted
            // Ensure even dimensions for h264/h265 encoders (pad/scale)
            videoFilters.add("scale=$targetW:$targetH:force_original_aspect_ratio=decrease,pad=$targetW:$targetH:(ow-iw)/2:(oh-ih)/2")
        } else {
            // Make sure dimensions are divisible by 2 for yuv420p encoders
            videoFilters.add("pad=ceil(iw/2)*2:ceil(ih/2)*2")
        }

        // FPS filter
        if (config.fps != TargetFps.ORIGINAL) {
            videoFilters.add("fps=${config.fps.fpsValue}")
        }

        if (videoFilters.isNotEmpty()) {
            args.add("-vf")
            args.add(videoFilters.joinToString(","))
        }

        // Video Codec selection
        val selectedVCodec = if (config.videoCodec == VideoCodec.AUTO || config.videoCodec == VideoCodec.COPY) {
            config.outputFormat.defaultVideoCodec
        } else {
            config.videoCodec
        }

        // Check hardware acceleration
        val videoEncoder = if (config.hardwareAccel == HardwareAccel.AUTO && selectedVCodec.hwEncoder != null) {
            selectedVCodec.hwEncoder
        } else {
            selectedVCodec.ffmpegEncoder
        }

        args.add("-c:v")
        args.add(videoEncoder)

        // Pixel format for wide compatibility
        if (selectedVCodec == VideoCodec.H264 || selectedVCodec == VideoCodec.H265) {
            args.add("-pix_fmt")
            args.add("yuv420p")
        }

        // Video Quality / Bitrate
        when (config.quality) {
            VideoQuality.ORIGINAL -> {
                if (selectedVCodec == VideoCodec.H264 || selectedVCodec == VideoCodec.H265) {
                    args.add("-crf")
                    args.add("20")
                }
            }
            VideoQuality.HIGH -> {
                if (selectedVCodec == VideoCodec.H264 || selectedVCodec == VideoCodec.H265) {
                    args.add("-crf")
                    args.add("18")
                } else {
                    args.add("-b:v")
                    args.add("4000k")
                }
            }
            VideoQuality.MEDIUM -> {
                if (selectedVCodec == VideoCodec.H264 || selectedVCodec == VideoCodec.H265) {
                    args.add("-crf")
                    args.add("23")
                } else {
                    args.add("-b:v")
                    args.add("2200k")
                }
            }
            VideoQuality.LOW -> {
                if (selectedVCodec == VideoCodec.H264 || selectedVCodec == VideoCodec.H265) {
                    args.add("-crf")
                    args.add("28")
                } else {
                    args.add("-b:v")
                    args.add("1000k")
                }
            }
            VideoQuality.CUSTOM -> {
                val bitrate = if (config.customBitrateKbps > 0) config.customBitrateKbps else 2000
                args.add("-b:v")
                args.add("${bitrate}k")
            }
        }

        // Preset for balanced performance on mobile devices
        if (selectedVCodec == VideoCodec.H264 || selectedVCodec == VideoCodec.H265) {
            args.add("-preset")
            args.add("ultrafast") // fastest encoding for Android mobile CPU
        }

        // Audio Handling
        when (config.audioHandling) {
            AudioHandling.REMOVE_AUDIO -> {
                args.add("-an")
            }
            AudioHandling.KEEP_ORIGINAL -> {
                // If container supports original audio codec, copy it; otherwise convert to default
                val targetContainer = config.outputFormat
                val aCodec = inputMetadata.audioCodec.lowercase()
                val canCopyAudio = when (targetContainer) {
                    VideoFormat.MP4 -> aCodec.contains("aac") || aCodec.contains("mp3")
                    VideoFormat.MKV -> true
                    VideoFormat.MOV -> aCodec.contains("aac")
                    VideoFormat.AVI -> aCodec.contains("mp3")
                    VideoFormat.WEBM -> aCodec.contains("opus") || aCodec.contains("vorbis")
                    VideoFormat.THREE_GP -> aCodec.contains("aac")
                    VideoFormat.MPEG -> aCodec.contains("mp2") || aCodec.contains("mp3")
                    VideoFormat.TS -> aCodec.contains("aac") || aCodec.contains("ac3")
                }

                if (canCopyAudio) {
                    args.add("-c:a")
                    args.add("copy")
                } else {
                    args.add("-c:a")
                    args.add(config.outputFormat.defaultAudioCodec.ffmpegEncoder)
                    args.add("-b:a")
                    args.add("160k")
                }
            }
            AudioHandling.CONVERT -> {
                val selectedACodec = if (config.audioCodec == AudioCodec.AUTO || config.audioCodec == AudioCodec.COPY) {
                    config.outputFormat.defaultAudioCodec
                } else {
                    config.audioCodec
                }
                args.add("-c:a")
                args.add(selectedACodec.ffmpegEncoder)
                args.add("-b:a")
                args.add("160k")
            }
        }

        // Container optimization
        if (config.outputFormat == VideoFormat.MP4 || config.outputFormat == VideoFormat.MOV) {
            args.add("-movflags")
            args.add("+faststart")
        }

        // Output destination
        args.add(outputFilePath)

        return GeneratedCommand(
            arguments = args,
            isRemuxing = false,
            explanation = "Transcoding: Re-encoding video with ${selectedVCodec.displayName} to ensure high quality and full container compatibility."
        )
    }
}
