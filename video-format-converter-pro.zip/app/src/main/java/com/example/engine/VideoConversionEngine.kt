package com.example.engine

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import java.io.File

sealed class EngineConversionEvent {
    data class Progress(val progress: ConversionProgress) : EngineConversionEvent()
    data class Completed(val result: ConversionResult) : EngineConversionEvent()
    data class Error(val message: String, val technicalDetails: String?) : EngineConversionEvent()
    object Cancelled : EngineConversionEvent()
}

class VideoConversionEngine(private val context: Context) {

    private var activeSession: FFmpegSession? = null
    private var isCancelled = false

    companion object {
        private const val TAG = "VideoConversionEngine"
    }

    /**
     * Cancels the active conversion session immediately.
     */
    fun cancelActiveConversion() {
        isCancelled = true
        activeSession?.let { session ->
            Log.d(TAG, "Cancelling active FFmpeg session: ${session.sessionId}")
            session.cancel()
            FFmpegKit.cancel(session.sessionId)
        }
    }

    /**
     * Executes conversion with real-time progress flow and comprehensive validation.
     */
    fun convertVideo(
        inputUri: Uri,
        inputMetadata: VideoMetadata,
        config: ConversionConfig
    ): Flow<EngineConversionEvent> = callbackFlow {
        isCancelled = false
        var tempInputFile: File? = null
        var tempOutputFile: File? = null

        try {
            // 1. Storage validation
            val availableBytes = StorageManager.getAvailableStorageBytes(context)
            val requiredBytes = if (inputMetadata.fileSizeBytes > 0) inputMetadata.fileSizeBytes * 2 else 50L * 1024 * 1024
            if (availableBytes < requiredBytes) {
                trySend(EngineConversionEvent.Error(
                    message = "Insufficient storage space. Need at least ${StorageManager.formatBytes(requiredBytes)}, available: ${StorageManager.formatBytes(availableBytes)}",
                    technicalDetails = "Storage check failed: available=$availableBytes, required=$requiredBytes"
                ))
                close()
                return@callbackFlow
            }

            // 2. Stream input URI to cache file
            trySend(EngineConversionEvent.Progress(ConversionProgress(percentage = 0, currentStage = "Preparing media…")))
            tempInputFile = MediaMetadataHelper.copyUriToCacheFile(context, inputUri, inputMetadata.fileName)

            // 3. Prepare output file
            val outputDir = File(context.cacheDir, "converter_outputs")
            if (!outputDir.exists()) outputDir.mkdirs()

            val ext = config.outputFormat.extension
            val baseName = config.outputFileName.ifBlank {
                inputMetadata.fileName.substringBeforeLast('.') + "_converted"
            }.replace("[/\\\\:*?\"<>|]".toRegex(), "_")
            val targetFileNameWithExt = if (baseName.endsWith(".$ext", ignoreCase = true)) baseName else "$baseName.$ext"

            tempOutputFile = File(outputDir, "out_${System.currentTimeMillis()}_$targetFileNameWithExt")

            // 4. Generate safe FFmpeg arguments
            val generatedCommand = FFmpegCommandGenerator.buildCommand(
                inputFilePath = tempInputFile.absolutePath,
                outputFilePath = tempOutputFile.absolutePath,
                inputMetadata = inputMetadata,
                config = config
            )

            Log.d(TAG, "Executing FFmpeg command: ${generatedCommand.asCommandLineString}")
            val stageDesc = if (generatedCommand.isRemuxing) "Remuxing stream…" else "Transcoding video…"
            trySend(EngineConversionEvent.Progress(ConversionProgress(percentage = 5, currentStage = stageDesc)))

            val totalDurationMs = if (inputMetadata.durationMs > 0) inputMetadata.durationMs else 1L
            val startTimeMs = System.currentTimeMillis()

            // 5. Execute with FFmpegKit
            activeSession = FFmpegKit.executeWithArgumentsAsync(
                generatedCommand.arguments.toTypedArray(),
                { session ->
                    // Completion Callback
                    val returnCode = session.returnCode
                    val logs = session.allLogsAsString
                    val failStackTrace = session.failStackTrace

                    if (ReturnCode.isSuccess(returnCode)) {
                        // 6. Output Validation
                        val validationError = validateOutputFile(tempOutputFile, config.outputFormat)
                        if (validationError != null) {
                            tempOutputFile.delete()
                            trySend(EngineConversionEvent.Error(
                                message = "Output validation failed: $validationError",
                                technicalDetails = "Validation failure after successful FFmpeg return code.\nLogs:\n$logs"
                            ))
                        } else {
                            // 7. Save to destination
                            try {
                                val (savedPath, savedUri) = kotlinx.coroutines.runBlocking {
                                    StorageManager.exportConvertedFile(
                                        context = context,
                                        tempOutputFile = tempOutputFile,
                                        targetFileName = targetFileNameWithExt,
                                        location = config.saveLocation,
                                        format = config.outputFormat
                                    )
                                }

                                val finalSize = tempOutputFile.length()
                                val finalDuration = extractDurationSafely(tempOutputFile)

                                trySend(EngineConversionEvent.Completed(
                                    ConversionResult(
                                        isSuccess = true,
                                        outputFilePath = savedPath,
                                        outputUri = savedUri,
                                        outputFileName = targetFileNameWithExt,
                                        outputSizeBytes = finalSize,
                                        durationMs = if (finalDuration > 0) finalDuration else inputMetadata.durationMs,
                                        format = config.outputFormat.extension.uppercase(),
                                        resolution = if (config.resolution != VideoResolution.ORIGINAL) {
                                            "${config.resolution.targetWidth}x${config.resolution.targetHeight}"
                                        } else {
                                            inputMetadata.resolutionFormatted
                                        }
                                    )
                                ))
                            } catch (saveErr: Exception) {
                                trySend(EngineConversionEvent.Error(
                                    message = "Failed to save converted file to ${config.saveLocation.name}: ${saveErr.message}",
                                    technicalDetails = saveErr.stackTraceToString()
                                ))
                            }
                        }
                    } else if (ReturnCode.isCancel(returnCode) || isCancelled) {
                        tempOutputFile.delete()
                        trySend(EngineConversionEvent.Cancelled)
                    } else {
                        // Conversion failed
                        tempOutputFile.delete()
                        val humanMessage = parseHumanReadableError(logs)
                        trySend(EngineConversionEvent.Error(
                            message = humanMessage,
                            technicalDetails = "FFmpeg returnCode: ${returnCode?.value}\nFail stack trace: $failStackTrace\nLogs:\n$logs"
                        ))
                    }
                    close()
                },
                { /* logCallback */ },
                { stats ->
                    // Real-time Statistics Callback
                    if (stats != null && !isCancelled) {
                        val processedMs = stats.time.toLong()
                        var percent = if (totalDurationMs > 0) {
                            ((processedMs.toDouble() / totalDurationMs.toDouble()) * 100).toInt()
                        } else {
                            0
                        }
                        percent = percent.coerceIn(0, 99)

                        val speed = stats.speed
                        val remainingMs = if (speed > 0 && totalDurationMs > processedMs) {
                            (((totalDurationMs - processedMs) / speed)).toLong()
                        } else {
                            0L
                        }

                        val sizeFormatted = StorageManager.formatBytes(stats.size)

                        trySend(EngineConversionEvent.Progress(
                            ConversionProgress(
                                percentage = percent,
                                processedMs = processedMs,
                                totalMs = totalDurationMs,
                                remainingTimeMs = remainingMs,
                                speedMultiplier = speed,
                                currentStage = stageDesc,
                                bitrateKbps = stats.bitrate,
                                currentSizeFormatted = sizeFormatted
                            )
                        ))
                    }
                }
            )

        } catch (e: Exception) {
            tempOutputFile?.delete()
            trySend(EngineConversionEvent.Error(
                message = "Conversion encountered an unexpected error: ${e.localizedMessage}",
                technicalDetails = e.stackTraceToString()
            ))
            close()
        }

        awaitClose {
            // Cleanup input temp cache file
            tempInputFile?.delete()
        }
    }

    private fun validateOutputFile(file: File, expectedFormat: VideoFormat): String? {
        if (!file.exists()) return "Converted file does not exist on disk."
        if (file.length() <= 0) return "Converted file is empty (0 bytes)."

        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            if (hasVideo == null || !hasVideo.equals("yes", ignoreCase = true)) {
                // Check if audio-only or valid container
                val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                if (dur == null || dur.toLongOrNull() == 0L) {
                    return "File contains no valid video stream."
                }
            }
            null // All checks pass
        } catch (e: Exception) {
            "Could not parse media container: ${e.message}"
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun extractDurationSafely(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun parseHumanReadableError(logs: String?): String {
        if (logs.isNullOrBlank()) return "Conversion failed due to an unknown encoder error."
        return when {
            logs.contains("No space left on device", ignoreCase = true) ->
                "Conversion failed: Insufficient device storage."
            logs.contains("Invalid data found when processing input", ignoreCase = true) ->
                "The selected video file appears to be corrupted or in an unsupported internal format."
            logs.contains("Unknown encoder", ignoreCase = true) ->
                "The requested codec is not supported by your device's encoder configuration."
            logs.contains("Permission denied", ignoreCase = true) ->
                "Permission denied while reading or writing video data."
            logs.contains("Error while opening encoder", ignoreCase = true) ->
                "Hardware encoder unavailable or busy. Please try converting with Software fallback in Settings."
            else -> {
                // Extract last non-empty line of FFmpeg logs
                val lines = logs.lines().filter { it.isNotBlank() }
                lines.takeLast(3).firstOrNull { it.contains("error", ignoreCase = true) }
                    ?: "Conversion stopped unexpectedly. Check technical details for more information."
            }
        }
    }
}
