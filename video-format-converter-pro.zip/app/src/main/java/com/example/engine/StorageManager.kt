package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.util.Log
import com.example.model.SaveLocation
import com.example.model.VideoFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object StorageManager {

    private const val TAG = "StorageManager"

    /**
     * Returns total available storage in bytes on internal/primary storage.
     */
    fun getAvailableStorageBytes(context: Context): Long {
        return try {
            val path = context.filesDir
            val stat = StatFs(path.path)
            stat.availableBlocksLong * stat.blockSizeLong
        } catch (e: Exception) {
            1024L * 1024L * 1024L // 1 GB fallback
        }
    }

    /**
     * Formats bytes into human-readable string.
     */
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            mb >= 1.0 -> String.format("%.1f MB", mb)
            else -> String.format("%.1f KB", kb)
        }
    }

    /**
     * Calculates storage used by this app's converted files directory.
     */
    fun getConvertedFilesSizeBytes(context: Context): Long {
        var total = 0L
        try {
            val appConvertedDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ConvertedVideos")
            if (appConvertedDir.exists()) {
                total += calculateDirSize(appConvertedDir)
            }
            val internalOutputs = File(context.filesDir, "converted_videos")
            if (internalOutputs.exists()) {
                total += calculateDirSize(internalOutputs)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error calculating converted files size: ${e.message}")
        }
        return total
    }

    /**
     * Counts the number of converted files stored.
     */
    fun getConvertedFilesCount(context: Context): Int {
        var count = 0
        try {
            val appConvertedDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ConvertedVideos")
            if (appConvertedDir.exists()) {
                count += appConvertedDir.listFiles()?.size ?: 0
            }
            val internalOutputs = File(context.filesDir, "converted_videos")
            if (internalOutputs.exists()) {
                count += internalOutputs.listFiles()?.size ?: 0
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error counting converted files: ${e.message}")
        }
        return count
    }

    private fun calculateDirSize(dir: File): Long {
        var size = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            size += if (f.isDirectory) calculateDirSize(f) else f.length()
        }
        return size
    }

    /**
     * Deletes converted files created by the app.
     */
    suspend fun clearConvertedFiles(context: Context): Boolean = withContext(Dispatchers.IO) {
        try {
            val appConvertedDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ConvertedVideos")
            if (appConvertedDir.exists()) {
                appConvertedDir.listFiles()?.forEach { it.delete() }
            }
            val internalOutputs = File(context.filesDir, "converted_videos")
            if (internalOutputs.exists()) {
                internalOutputs.listFiles()?.forEach { it.delete() }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing converted files: ${e.message}")
            false
        }
    }

    /**
     * Saves a completed video file to the requested destination (Downloads, Movies, or App Storage).
     * Uses MediaStore on modern Android for zero-permission saving to Downloads or Movies.
     */
    suspend fun exportConvertedFile(
        context: Context,
        tempOutputFile: File,
        targetFileName: String,
        location: SaveLocation,
        format: VideoFormat
    ): Pair<String, Uri?> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mimeType = format.mimeType

        when (location) {
            SaveLocation.DOWNLOADS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, targetFileName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoConverter")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }

                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Failed to create MediaStore entry in Downloads")

                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(tempOutputFile).use { input ->
                            input.copyTo(out)
                        }
                    }

                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)

                    return@withContext Pair(tempOutputFile.absolutePath, uri)
                } else {
                    // Fallback to external files directory
                    val destDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "VideoConverter")
                    if (!destDir.exists()) destDir.mkdirs()
                    val destFile = File(destDir, targetFileName)
                    tempOutputFile.copyTo(destFile, overwrite = true)
                    return@withContext Pair(destFile.absolutePath, Uri.fromFile(destFile))
                }
            }
            SaveLocation.MOVIES -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, targetFileName)
                        put(MediaStore.Video.Media.MIME_TYPE, mimeType)
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoConverter")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }

                    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Failed to create MediaStore entry in Movies")

                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(tempOutputFile).use { input ->
                            input.copyTo(out)
                        }
                    }

                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)

                    return@withContext Pair(tempOutputFile.absolutePath, uri)
                } else {
                    val destDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ConvertedVideos")
                    if (!destDir.exists()) destDir.mkdirs()
                    val destFile = File(destDir, targetFileName)
                    tempOutputFile.copyTo(destFile, overwrite = true)
                    return@withContext Pair(destFile.absolutePath, Uri.fromFile(destFile))
                }
            }
            SaveLocation.APP_STORAGE -> {
                val destDir = File(context.filesDir, "converted_videos")
                if (!destDir.exists()) destDir.mkdirs()
                val destFile = File(destDir, targetFileName)
                tempOutputFile.copyTo(destFile, overwrite = true)
                return@withContext Pair(destFile.absolutePath, Uri.fromFile(destFile))
            }
        }
    }
}
