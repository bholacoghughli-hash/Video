package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.engine.FFmpegCommandGenerator
import com.example.model.*
import com.example.ui.components.ConversionProgressBar
import com.example.ui.components.VideoPreviewPlayer
import com.example.viewmodel.ConversionViewModel
import com.example.viewmodel.UiConversionState
import java.io.File

@Composable
fun ConvertScreen(
    viewModel: ConversionViewModel,
    onOpenVideo: (String) -> Unit,
    onShareVideo: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val conversionState by viewModel.conversionState.collectAsState()
    val config by viewModel.config.collectAsState()

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onVideoSelected(uri)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        when (val state = conversionState) {
            is UiConversionState.Idle -> {
                EmptySelectVideoView(
                    onSelect = { filePicker.launch("video/*") }
                )
            }
            is UiConversionState.LoadingMetadata -> {
                LoadingMetadataView(fileName = state.fileName)
            }
            is UiConversionState.Ready -> {
                ConversionConfigurationView(
                    metadata = state.metadata,
                    config = config,
                    onConfigChange = { update -> viewModel.updateConfig(update) },
                    onStartConversion = { viewModel.startConversion() },
                    onSelectDifferent = { filePicker.launch("video/*") }
                )
            }
            is UiConversionState.Converting -> {
                ConvertingView(
                    progress = state.progress,
                    inputFileName = state.metadata.fileName,
                    outputFileName = config.outputFileName,
                    onCancel = { viewModel.cancelConversion() }
                )
            }
            is UiConversionState.Completed -> {
                ConversionCompleteView(
                    result = state.result,
                    onOpen = { state.result.outputFilePath?.let { onOpenVideo(it) } },
                    onShare = { state.result.outputFilePath?.let { onShareVideo(it) } },
                    onConvertAnother = { viewModel.resetToReady() },
                    onSelectNew = { filePicker.launch("video/*") },
                    onDeleteOutput = {
                        state.result.outputFilePath?.let { File(it).delete() }
                        viewModel.resetToReady()
                    }
                )
            }
            is UiConversionState.Error -> {
                ConversionErrorView(
                    errorMessage = state.message,
                    technicalDetails = state.technicalDetails,
                    onRetry = { viewModel.startConversion() },
                    onAdjustSettings = { viewModel.resetToReady() },
                    onSelectNew = { filePicker.launch("video/*") }
                )
            }
        }
    }
}

@Composable
private fun EmptySelectVideoView(onSelect: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CloudUpload,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Select a Video to Convert",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Supports MP4, MKV, MOV, AVI, WEBM, 3GP, FLV, TS, MPEG, and more.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onSelect,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(52.dp)
                .testTag("empty_select_video_button"),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(imageVector = Icons.Default.VideoFile, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.select_video),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun LoadingMetadataView(fileName: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(52.dp),
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "Analyzing Video Stream…",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = fileName,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
private fun ConversionConfigurationView(
    metadata: VideoMetadata,
    config: ConversionConfig,
    onConfigChange: ((ConversionConfig) -> ConversionConfig) -> Unit,
    onStartConversion: () -> Unit,
    onSelectDifferent: () -> Unit
) {
    val isRemuxPossible = remember(metadata, config) {
        FFmpegCommandGenerator.canRemux(metadata, config)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Video Preview Component
        item {
            VideoPreviewPlayer(videoUri = metadata.uri)
        }

        // Technical Specs Grid
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Input Video Details",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = onSelectDifferent) {
                            Text("Change Video")
                        }
                    }

                    SpecsRow(label = "Filename", value = metadata.fileName)
                    SpecsRow(label = "Container", value = metadata.formatName)
                    SpecsRow(label = "Resolution", value = metadata.resolutionFormatted)
                    SpecsRow(label = "Duration", value = metadata.durationFormatted)
                    SpecsRow(label = "File Size", value = metadata.fileSizeFormatted)
                    SpecsRow(label = "Frame Rate", value = metadata.fpsFormatted)
                    SpecsRow(label = "Video Codec", value = metadata.videoCodec)
                    SpecsRow(label = "Audio Codec", value = metadata.audioCodec)
                }
            }
        }

        // Remuxing / Transcoding Badge
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = if (isRemuxPossible) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (isRemuxPossible) Icons.Default.Bolt else Icons.Default.Transform,
                        contentDescription = null,
                        tint = if (isRemuxPossible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                    )
                    Column {
                        Text(
                            text = if (isRemuxPossible) "Fast Lossless Remuxing" else "High-Quality Transcoding",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isRemuxPossible)
                                stringResource(R.string.remux_notice)
                            else
                                stringResource(R.string.transcode_notice),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Output Settings Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = stringResource(R.string.conversion_settings),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    // Output Format Selector
                    DropdownSetting(
                        label = stringResource(R.string.output_format),
                        selectedText = config.outputFormat.containerName,
                        options = VideoFormat.values().map { it.containerName },
                        onSelect = { selectedName ->
                            val format = VideoFormat.values().first { it.containerName == selectedName }
                            onConfigChange { it.copy(outputFormat = format) }
                        }
                    )

                    // Video Codec Selector (Compatible with output format)
                    val compatibleVCodecs = remember(config.outputFormat) {
                        listOf(VideoCodec.AUTO) + config.outputFormat.supportedVideoCodecs
                    }
                    DropdownSetting(
                        label = stringResource(R.string.video_codec),
                        selectedText = config.videoCodec.displayName,
                        options = compatibleVCodecs.map { it.displayName },
                        onSelect = { name ->
                            val codec = compatibleVCodecs.first { it.displayName == name }
                            onConfigChange { it.copy(videoCodec = codec) }
                        }
                    )

                    // Audio Codec Selector
                    val compatibleACodecs = remember(config.outputFormat) {
                        listOf(AudioCodec.AUTO) + config.outputFormat.supportedAudioCodecs
                    }
                    DropdownSetting(
                        label = stringResource(R.string.audio_codec),
                        selectedText = config.audioCodec.displayName,
                        options = compatibleACodecs.map { it.displayName },
                        onSelect = { name ->
                            val codec = compatibleACodecs.first { it.displayName == name }
                            onConfigChange { it.copy(audioCodec = codec) }
                        }
                    )

                    // Resolution
                    DropdownSetting(
                        label = stringResource(R.string.resolution),
                        selectedText = config.resolution.displayName,
                        options = VideoResolution.values().map { it.displayName },
                        onSelect = { name ->
                            val res = VideoResolution.values().first { it.displayName == name }
                            onConfigChange { it.copy(resolution = res) }
                        }
                    )

                    // FPS
                    DropdownSetting(
                        label = stringResource(R.string.fps),
                        selectedText = config.fps.displayName,
                        options = TargetFps.values().map { it.displayName },
                        onSelect = { name ->
                            val fps = TargetFps.values().first { it.displayName == name }
                            onConfigChange { it.copy(fps = fps) }
                        }
                    )

                    // Video Quality
                    DropdownSetting(
                        label = stringResource(R.string.video_quality),
                        selectedText = "${config.quality.displayName} - ${config.quality.description}",
                        options = VideoQuality.values().map { "${it.displayName} - ${it.description}" },
                        onSelect = { name ->
                            val quality = VideoQuality.values().first { "${it.displayName} - ${it.description}" == name }
                            onConfigChange { it.copy(quality = quality) }
                        }
                    )

                    // Custom Bitrate if custom quality selected
                    if (config.quality == VideoQuality.CUSTOM) {
                        OutlinedTextField(
                            value = config.customBitrateKbps.toString(),
                            onValueChange = { str ->
                                val num = str.toIntOrNull() ?: 2000
                                onConfigChange { it.copy(customBitrateKbps = num) }
                            },
                            label = { Text(stringResource(R.string.custom_bitrate_kbps)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Audio Handling
                    val keepAudioText = stringResource(R.string.keep_original_audio)
                    val convertAudioText = stringResource(R.string.convert_audio)
                    val removeAudioText = stringResource(R.string.remove_audio)

                    DropdownSetting(
                        label = stringResource(R.string.audio_handling),
                        selectedText = when (config.audioHandling) {
                            AudioHandling.KEEP_ORIGINAL -> keepAudioText
                            AudioHandling.CONVERT -> convertAudioText
                            AudioHandling.REMOVE_AUDIO -> removeAudioText
                        },
                        options = listOf(keepAudioText, convertAudioText, removeAudioText),
                        onSelect = { name ->
                            val handling = when (name) {
                                convertAudioText -> AudioHandling.CONVERT
                                removeAudioText -> AudioHandling.REMOVE_AUDIO
                                else -> AudioHandling.KEEP_ORIGINAL
                            }
                            onConfigChange { it.copy(audioHandling = handling) }
                        }
                    )

                    // Hardware Acceleration
                    val hwAutoText = stringResource(R.string.hw_auto)
                    val hwSoftwareText = stringResource(R.string.hw_software)

                    DropdownSetting(
                        label = stringResource(R.string.hardware_accel),
                        selectedText = when (config.hardwareAccel) {
                            HardwareAccel.AUTO -> hwAutoText
                            HardwareAccel.SOFTWARE -> hwSoftwareText
                        },
                        options = listOf(hwAutoText, hwSoftwareText),
                        onSelect = { name ->
                            val hw = if (name == hwSoftwareText) HardwareAccel.SOFTWARE else HardwareAccel.AUTO
                            onConfigChange { it.copy(hardwareAccel = hw) }
                        }
                    )

                    // Output Filename
                    OutlinedTextField(
                        value = config.outputFileName,
                        onValueChange = { onConfigChange { cfg -> cfg.copy(outputFileName = it) } },
                        label = { Text(stringResource(R.string.output_filename)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("output_filename_input"),
                        singleLine = true
                    )

                    // Save Location
                    val saveDownloadsText = stringResource(R.string.save_downloads)
                    val saveMoviesText = stringResource(R.string.save_movies)
                    val saveAppStorageText = stringResource(R.string.save_app_storage)

                    DropdownSetting(
                        label = stringResource(R.string.output_location),
                        selectedText = when (config.saveLocation) {
                            SaveLocation.DOWNLOADS -> saveDownloadsText
                            SaveLocation.MOVIES -> saveMoviesText
                            SaveLocation.APP_STORAGE -> saveAppStorageText
                        },
                        options = listOf(saveDownloadsText, saveMoviesText, saveAppStorageText),
                        onSelect = { name ->
                            val loc = when (name) {
                                saveMoviesText -> SaveLocation.MOVIES
                                saveAppStorageText -> SaveLocation.APP_STORAGE
                                else -> SaveLocation.DOWNLOADS
                            }
                            onConfigChange { it.copy(saveLocation = loc) }
                        }
                    )
                }
            }
        }

        // Convert Button (Primary Action)
        item {
            Button(
                onClick = onStartConversion,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("start_conversion_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(imageVector = Icons.Default.Transform, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.start_conversion),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun ConvertingView(
    progress: ConversionProgress,
    inputFileName: String,
    outputFileName: String,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        ConversionProgressBar(
            progress = progress,
            inputFileName = inputFileName,
            outputFileName = outputFileName,
            onCancel = onCancel
        )
    }
}

@Composable
private fun ConversionCompleteView(
    result: ConversionResult,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onConvertAnother: () -> Unit,
    onSelectNew: () -> Unit,
    onDeleteOutput: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        item {
            Text(
                text = stringResource(R.string.conversion_complete),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Details Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SpecsRow(label = "Output File", value = result.outputFileName)
                    SpecsRow(label = "Format", value = result.format)
                    SpecsRow(label = "Resolution", value = result.resolution)
                    SpecsRow(label = "File Size", value = formatBytes(result.outputSizeBytes))
                    SpecsRow(label = "Duration", value = formatDurationMs(result.durationMs))
                    if (result.outputFilePath != null) {
                        SpecsRow(label = "Saved Location", value = result.outputFilePath)
                    }
                }
            }
        }

        // Action Buttons Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("open_video_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.open_video))
                }

                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("share_video_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.share_video))
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onConvertAnother,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(stringResource(R.string.convert_another))
                }

                OutlinedButton(
                    onClick = onDeleteOutput,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.delete_output))
                }
            }
        }
    }
}

@Composable
private fun ConversionErrorView(
    errorMessage: String,
    technicalDetails: String?,
    onRetry: () -> Unit,
    onAdjustSettings: () -> Unit,
    onSelectNew: () -> Unit
) {
    var showTechDetails by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.errorContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        item {
            Text(
                text = stringResource(R.string.conversion_failed),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
            )
        }

        item {
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        if (!technicalDetails.isNullOrBlank()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showTechDetails = !showTechDetails },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.technical_details),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(
                                imageVector = if (showTechDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                        }

                        AnimatedVisibility(
                            visible = showTechDetails,
                            enter = expandVertically(),
                            exit = shrinkVertically()
                        ) {
                            Text(
                                text = technicalDetails,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = onAdjustSettings,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Adjust Settings")
            }
        }

        item {
            OutlinedButton(
                onClick = onSelectNew,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Select Different Video")
            }
        }
    }
}

@Composable
private fun SpecsRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DropdownSetting(
    label: String,
    selectedText: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selectedText,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 MB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.2f GB", gb)
        mb >= 1.0 -> String.format("%.2f MB", mb)
        else -> String.format("%.1f KB", kb)
    }
}

private fun formatDurationMs(millis: Long): String {
    if (millis <= 0) return "00:00"
    val totalSeconds = millis / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
