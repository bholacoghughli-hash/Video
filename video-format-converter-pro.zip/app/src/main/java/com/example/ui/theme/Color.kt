package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Tech Indigo & Cyan palette
val Navy900 = Color(0xFF0A1128)
val Navy800 = Color(0xFF001F54)
val Blue700 = Color(0xFF034078)
val Blue600 = Color(0xFF1282A2)
val CyanAccent = Color(0xFF00D2FF)
val CyanDark = Color(0xFF0096C7)

// Neutral & Backgrounds - Dark Mode
val DarkBackground = Color(0xFF0D131F)
val DarkSurface = Color(0xFF141D2D)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

// Neutral & Backgrounds - Light Mode
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

// Accent & Status Colors
val GreenSuccess = Color(0xFF10B981)
val GreenSuccessContainer = Color(0xFF064E3B)
val RedError = Color(0xFFEF4444)
val RedErrorContainer = Color(0xFF7F1D1D)
val AmberWarning = Color(0xFFF59E0B)
