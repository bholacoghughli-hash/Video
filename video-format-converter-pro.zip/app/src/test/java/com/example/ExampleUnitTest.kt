package com.example

import android.net.Uri
import com.example.engine.FFmpegCommandGenerator
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    @Test
    fun testSupportedInputFormats() {
        assertTrue(VideoFormat.isInputSupported("mp4"))
        assertTrue(VideoFormat.isInputSupported("mkv"))
        assertTrue(VideoFormat.isInputSupported("mov"))
        assertTrue(VideoFormat.isInputSupported("avi"))
        assertTrue(VideoFormat.isInputSupported("webm"))
        assertTrue(VideoFormat.isInputSupported("flv"))
        assertTrue(VideoFormat.isInputSupported("3gp"))
        assertTrue(VideoFormat.isInputSupported("mpeg"))
        assertTrue(VideoFormat.isInputSupported("mpg"))
        assertTrue(VideoFormat.isInputSupported("ts"))
        assertTrue(VideoFormat.isInputSupported("m4v"))

        assertFalse(VideoFormat.isInputSupported("exe"))
        assertFalse(VideoFormat.isInputSupported("pdf"))
        assertFalse(VideoFormat.isInputSupported("mp3"))
    }

    @Test
    fun testSupportedOutputFormats() {
        val formats = VideoFormat.values()
        val extensions = formats.map { it.extension }

        assertTrue(extensions.contains("mp4"))
        assertTrue(extensions.contains("mkv"))
        assertTrue(extensions.contains("mov"))
        assertTrue(extensions.contains("avi"))
        assertTrue(extensions.contains("webm"))
        assertTrue(extensions.contains("3gp"))
        assertTrue(extensions.contains("mpeg"))
        assertTrue(extensions.contains("ts"))
    }

    @Test
    fun testRemuxingDetectionWhenCompatible() {
        val dummyUri = Uri.parse("content://media/external/video/media/1")
        val metadata = VideoMetadata(
            uri = dummyUri,
            fileName = "sample_clip.mp4",
            fileSizeBytes = 10_000_000,
            durationMs = 60_000,
            width = 1920,
            height = 1080,
            videoCodec = "H.264 / AVC",
            audioCodec = "AAC"
        )

        // Convert MP4 (h264/aac) to MKV without changing resolution or audio -> should remux!
        val config = ConversionConfig(
            outputFormat = VideoFormat.MKV,
            resolution = VideoResolution.ORIGINAL,
            fps = TargetFps.ORIGINAL,
            quality = VideoQuality.MEDIUM,
            audioHandling = AudioHandling.KEEP_ORIGINAL
        )

        val canRemux = FFmpegCommandGenerator.canRemux(metadata, config)
        assertTrue("H.264 + AAC in MKV container should be remuxable without transcoding", canRemux)

        val command = FFmpegCommandGenerator.buildCommand(
            inputFilePath = "/dummy/input.mp4",
            outputFilePath = "/dummy/output.mkv",
            inputMetadata = metadata,
            config = config
        )

        assertTrue(command.isRemuxing)
        assertTrue(command.arguments.contains("-c:v"))
        assertTrue(command.arguments.contains("copy"))
        assertTrue(command.arguments.contains("-c:a"))
    }

    @Test
    fun testTranscodingWhenResolutionChanges() {
        val dummyUri = Uri.parse("content://media/external/video/media/1")
        val metadata = VideoMetadata(
            uri = dummyUri,
            fileName = "sample_clip.mp4",
            fileSizeBytes = 10_000_000,
            durationMs = 60_000,
            width = 1920,
            height = 1080,
            videoCodec = "H.264 / AVC",
            audioCodec = "AAC"
        )

        // User requests downscaling to 720p -> must transcode!
        val config = ConversionConfig(
            outputFormat = VideoFormat.MP4,
            resolution = VideoResolution.P720,
            fps = TargetFps.ORIGINAL
        )

        val canRemux = FFmpegCommandGenerator.canRemux(metadata, config)
        assertFalse("Changing resolution requires transcoding", canRemux)

        val command = FFmpegCommandGenerator.buildCommand(
            inputFilePath = "/dummy/input.mp4",
            outputFilePath = "/dummy/output.mp4",
            inputMetadata = metadata,
            config = config
        )

        assertFalse(command.isRemuxing)
        assertTrue(command.arguments.contains("-vf"))
        val vfIndex = command.arguments.indexOf("-vf")
        assertTrue(command.arguments[vfIndex + 1].contains("1280:720"))
    }

    @Test
    fun testSafeArgumentGenerationWithSpecialCharacters() {
        val dummyUri = Uri.parse("content://media/external/video/media/1")
        val metadata = VideoMetadata(
            uri = dummyUri,
            fileName = "नमस्ते video 🎬 file (1).mp4",
            fileSizeBytes = 5_000_000,
            durationMs = 30_000,
            width = 1280,
            height = 720,
            videoCodec = "H.264 / AVC",
            audioCodec = "AAC"
        )

        val config = ConversionConfig(
            outputFormat = VideoFormat.MP4,
            outputFileName = "आउटपुट video 🎬"
        )

        val inputPath = "/storage/emulated/0/नमस्ते video 🎬 file (1).mp4"
        val outputPath = "/storage/emulated/0/आउटपुट video 🎬.mp4"

        val command = FFmpegCommandGenerator.buildCommand(
            inputFilePath = inputPath,
            outputFilePath = outputPath,
            inputMetadata = metadata,
            config = config
        )

        // Verifies that input and output are correctly isolated arguments (no shell injection)
        assertTrue(command.arguments.contains(inputPath))
        assertTrue(command.arguments.contains(outputPath))
    }

    @Test
    fun testDeveloperInformationAndSafeIntents() {
        val devName = "Bhaskar Gautam"
        val devAge = "14 years"
        val devPhone = "9936293542"
        val devEmail = "Bhola.co.ghughli@gmail.com"
        val devAddress = "Munderi, Siswa, Maharajganj, Uttar Pradesh, India"

        assertEquals("Bhaskar Gautam", devName)
        assertEquals("14 years", devAge)
        assertEquals("9936293542", devPhone)
        assertEquals("Bhola.co.ghughli@gmail.com", devEmail)
        assertTrue(devAddress.contains("Munderi"))
        assertTrue(devAddress.contains("Siswa"))
        assertTrue(devAddress.contains("Maharajganj"))
        assertTrue(devAddress.contains("Uttar Pradesh"))
        assertTrue(devAddress.contains("India"))

        // Test safe mailto intent URI structure
        val emailUri = Uri.parse("mailto:$devEmail")
        assertEquals("mailto", emailUri.scheme)
        assertEquals("Bhola.co.ghughli@gmail.com", emailUri.schemeSpecificPart)

        // Test safe dialer intent URI structure (not auto-calling)
        val dialUri = Uri.parse("tel:$devPhone")
        assertEquals("tel", dialUri.scheme)
        assertEquals("9936293542", dialUri.schemeSpecificPart)
    }
}

